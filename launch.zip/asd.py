asdd = ['нвидиа', 'рыкса', 'интел']
print(asdd)
ass =  " \n".join(asdd)
print(ass)
input()